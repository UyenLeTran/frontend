- Tất cả thẻ li sẽ có màu tím (purple)
- Tất cả thẻ h1 và h2 sẽ có màu "blue" (viết chung css không viết riêng)
- Thẻ có id "submit" sẽ có màu nền là "green"
- Thẻ span nằm bên trong thẻ có id "courses" có màu đỏ
- Tất cả các thẻ có class "type" sẽ có text màu "magenta"
- Thẻ input có type là email sẽ có màu nền là "orange"
- Tất cả thẻ link có href kết thúc là ".org" sẽ có màu chữ là "magenta"
- Thẻ h2 có class "bright" sẽ có màu chữ là "cyan"

