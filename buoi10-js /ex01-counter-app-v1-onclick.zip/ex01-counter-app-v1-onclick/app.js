let elNumber = document.getElementById('number');
let elSavedNumber = document.getElementById('saved-number');

function decrement() {
  let number = parseInt(elNumber.innerText);
  number -= 1;
  elNumber.innerText = number;
}

function increment() {
  let number = parseInt(elNumber.innerText);
  number += 1;
  elNumber.innerText = number;
}

function reset() {
  elNumber.innerText = 0;
}

function save() {
  let number = parseInt(elNumber.innerText);
  let str = number + '|';
  elSavedNumber.innerText += str;
  elNumber.innerText = 0;
}
