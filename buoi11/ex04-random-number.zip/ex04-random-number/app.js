let inputMin = document.getElementById('min');
let inputMax = document.getElementById('max');
let inputResult = document.getElementById('result');
let btnGenerate = document.getElementById('btn-generate');

btnGenerate.addEventListener('click', function () {
  let min = inputMin.value;
  let max = inputMax.value;

  if (!min || !max) {
    alert('Vui lòng nhập đủ giá trị min và max')
  } else {
    let random = getRandom(min, max);
    inputResult.value = random;
  }
});

function getRandom(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1) + min); // The maximum is inclusive and the minimum is inclusive
}
