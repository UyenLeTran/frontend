let scoreHome = 0;
let scoreAway = 0;
let boxScoreHome = document.querySelector('.box-score.home');
let boxScoreAway = document.querySelector('.box-score.away');

// Code bên dưới chưa hoàn thành, chỉ dùng demo
// Bài này để học viên tự tư duy thực hành theo các kiến thức ở hai bài tập trước
let listBtn = document.getElementsByClassName('btn');
for (let i = 0; i < listBtn.length; i++) {
  listBtn[i].addEventListener('click', function () {
    let score = parseInt(listBtn[i].innerText);
    if (listBtn[i].classList.contains('home')) {
      scoreHome += score;
      if (scoreHome < 10) {
        boxScoreHome.innerText = '0' + scoreHome;
      } else {
        boxScoreHome.innerText = scoreHome;
      }
    } else {
      scoreAway += score;
      if (scoreAway < 10) {
        boxScoreAway.innerText = '0' + scoreAway;
      } else {
        boxScoreAway.innerText = scoreAway;
      }
    }
  })
}