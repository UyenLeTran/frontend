const MIN_FONT_SIZE = 10;
const MAX_FONT_SIZE = 40;
const STEP_FONT_SIZE = 2;
const elContent = document.getElementById('content');
const elLineHeightDisplayValue = document.getElementById('lineHeightDisplayValue');
const elInputLineHeight = document.getElementById('inputLineHeight');
const elInputColor = document.getElementById('inputColor');
const elSlbTextAlign = document.getElementById('slbTextAlign');
const elBtnBackgrounds = document.getElementsByClassName('btn-background');
const elBtnFontSizeDecrease = document.getElementById('btnFontSizeDecrease');
const elBtnFontSizeIncrease = document.getElementById('btnFontSizeIncrease');
const elBtnFontSizes = document.getElementsByClassName('btn-font-size');

for (let i = 0; i < elBtnFontSizes.length; i++) {
  const el = elBtnFontSizes[i];
  el.addEventListener('click', () => {
    const currentValue = parseInt(getComputedStyle(elContent).fontSize);
    const isDecrease = el.classList.contains('decrease');

    if (isDecrease) {
      const newValue = currentValue - STEP_FONT_SIZE;
      if (newValue < MIN_FONT_SIZE) return;
    } else {
      const newValue = currentValue + STEP_FONT_SIZE;
      if (newValue > MAX_FONT_SIZE) return;
    }

    elContent.style.fontSize = newValue + 'px';
  });
}

elInputLineHeight.addEventListener('input', () => {
  elLineHeightDisplayValue.textContent = changeValue(elInputLineHeight, 'lineHeight');
});

elSlbTextAlign.addEventListener('change', () => {
  changeValue(elSlbTextAlign, 'textAlign');
});

elInputColor.addEventListener('change', () => {
  changeValue(elInputColor, 'color');
});

for (let i = 0; i < elBtnBackgrounds.length; i++) {
  const el = elBtnBackgrounds[i];
  el.addEventListener('click', () => {
    const value = getComputedStyle(el).backgroundColor;
    elContent.style.backgroundColor = value;
  });
}

function changeValue(el, key) {
  const value = el.value;
  elContent.style[key] = value;
  return value;
}
